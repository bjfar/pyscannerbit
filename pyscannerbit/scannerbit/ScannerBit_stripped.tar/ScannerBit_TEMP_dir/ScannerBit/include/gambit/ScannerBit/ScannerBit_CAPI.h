//  GAMBIT: Global and Modular BSM Inference Tool
//  *********************************************
///  \file
///
///  Header for ScannerBit interface function 
///  library, for running ScannerBit via an 
//   external interface.
///  (For example, see pyScannerBit for a python
///   interface to these functions)
///
///  The filename says "C" API, but I really just
///  just mean C-style API. It still uses
///  C++ functionality.
///
///  *********************************************
///
///  Authors (add name and date if you modify):
///
///  \author Ben Farmer
///          (ben.farmer@gmail.com)
///  \date 2017 Nov
///
///  *********************************************

#ifndef __ScannerBit_CAPI_hpp__
#define __ScannerBit_CAPI_hpp__

#include <unordered_map>
#include <map>
#include <string>
#include "yaml-cpp/yaml.h"
//#include "gambit/ScannerBit/priors/composite.hpp"
//#include "gambit/ScannerBit/priors/user_supplied.hpp"
//#include "gambit/ScannerBit/base_userfunc.hpp"
#include "gambit/Utils/export_symbols.hpp"

// Control visibility of symbols
//#define EXPORT_SYMBOLS __attribute__ ((visibility ("default")))

// Interface function declarations

/// Required signature of the user-supplied likelihood function
typedef double (*user_funcptr)(const std::unordered_map<std::string, double> &in);    

/*
namespace Gambit {
    namespace Priors {
        //class UserFunc; // Forward declaration

        /// Object to manage a set of user-supplied functions to perform prior
        /// transformations. Keeps track of which function is supposed to 
        /// transform which parameters. Is a kind of 'precursor' to the 
        /// CompositePrior class which ultimately handles this during a scan.
        class EXPORT_SYMBOLS UserFuncPriorManager
        {
            private:
                // Map from vectors of parameters to their assigned prior function
                std::map<std::vector<std::string>, const UserFunc* > userfuncs;
        
                // Map to keep track of which UserFuncs have been successfully attached
                // to the prior object
                std::map<std::vector<std::string>, bool> matched;
        
            public:
                UserFuncPriorManager();
                UserFuncPriorManager(const std::map<std::vector<std::string>, const UserFunc* >& userfuncs);
        
                // Attempt to attach all userfuncs to the supplied prior
                void attach_UserFuncs(Gambit::Priors::CompositePrior& prior);
        };
    }
}
*/

#ifdef __cplusplus
extern "C"
{
#endif

    void EXPORT_SYMBOLS hello_world();

    /// Note: In the 'run' functions it is assumed that ScannerBit will handle MPI initialisation and
    /// finalisation. However, if you want to run multiple scans in a single session then you should
    /// set 'init_MPI' to false and handle this yourself in your calling code. 

    /// Run a scan using settings from a YAML file
    void EXPORT_SYMBOLS run_scan_from_file(const char[], const user_funcptr, bool init_MPI=true);

    /// Run a scan using settings from a YAML Node
    void EXPORT_SYMBOLS run_scan(YAML::Node, const user_funcptr, bool init_MPI=true);

#ifdef __cplusplus
}
#endif

//#undef EXPORT_SYMBOLS
#endif
