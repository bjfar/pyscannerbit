// Header to declare mkpath function in J Leffler's mkpath.cpp

#ifndef __mkpath_h__                 
#define __mkpath_h__                 

void recursive_mkdir(const char*);

#endif
